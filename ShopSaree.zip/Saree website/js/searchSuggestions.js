//product suggestions can be added here ... 
let suggestions = [
    "Leather Bag - Product",
    "Leather Bagpack - Product",
    "Leather Cap - Product",
    "Leather Purse - Product",
    "Products Page",
    "About Page",
    "Contributors",
    "Testimonials",
    "Customer Review",
    "Contact Us",
    "How to contact for issue",
    "How to repote a issue",
    "Cap - Product",
    "Bagpack - Product",
    "Purse - Procduct",
]